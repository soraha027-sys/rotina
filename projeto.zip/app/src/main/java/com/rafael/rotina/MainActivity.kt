package com.rafael.rotina

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity(), BridgeHost {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0B0B0B"))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.textZoom = 100
        web.addJavascriptInterface(Bridge(applicationContext, this, fromOverlay = false), "RotinaNative")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                !request.url.toString().startsWith("file:///android_asset/")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.onBack?window.onBack():'false'") { r ->
                    if (r?.contains("true") != true) {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })
        ReminderService.send(this, ReminderService.ACTION_START)
    }

    override fun onStart() {
        super.onStart()
        ReminderService.appVisible = true
        ReminderService.ping(this, ReminderService.ACTION_APP_SHOWN)
    }

    override fun onStop() {
        ReminderService.appVisible = false
        ReminderService.ping(this, ReminderService.ACTION_APP_HIDDEN)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("window.onNativeResume&&window.onNativeResume()", null)
        ReminderService.send(this, ReminderService.ACTION_START)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        web.evaluateJavascript("window.onNativeResume&&window.onNativeResume()", null)
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    // ---------- pedidos do JS ----------

    override fun theme(dark: Boolean) {
        val c = if (dark) Color.parseColor("#0B0B0B") else Color.parseColor("#E7E7E2")
        @Suppress("DEPRECATION")
        window.statusBarColor = c
        @Suppress("DEPRECATION")
        window.navigationBarColor = c
        web.setBackgroundColor(c)
        val ctl = WindowInsetsControllerCompat(window, window.decorView)
        ctl.isAppearanceLightStatusBars = !dark
        ctl.isAppearanceLightNavigationBars = !dark
    }

    override fun openPerm(key: String) {
        val pkg = Uri.parse("package:$packageName")
        val details = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
        when (key) {
            "overlay" -> open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg), details)
            "notif" -> {
                val prefs = getSharedPreferences("ui", Context.MODE_PRIVATE)
                if (Build.VERSION.SDK_INT >= 33 && !prefs.getBoolean("asked_notif", false)) {
                    prefs.edit().putBoolean("asked_notif", true).apply()
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
                } else {
                    open(
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName),
                        details,
                    )
                }
            }
            "alarm" -> if (Build.VERSION.SDK_INT >= 31) {
                open(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg), details)
            }
            "battery" -> open(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg),
                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            )
        }
    }

    private fun open(primary: Intent, fallback: Intent?) {
        try {
            startActivity(primary)
        } catch (e: Exception) {
            if (fallback != null) {
                try {
                    startActivity(fallback)
                } catch (e2: Exception) {
                    // nada a fazer
                }
            }
        }
    }
}
