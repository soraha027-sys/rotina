package com.rafael.rotina

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "rotina")

data class Task(
    val id: Long,
    val name: String,
    val minimal: String,
    val doneDay: String = "",
    val doneMinimal: Boolean = false,
) {
    fun isDone(today: String): Boolean = doneDay == today
}

data class AppState(
    val tasks: List<Task>,
    val xp: Int,
    val streak: Int,
    val lastClosedDay: String,
    val intervalHours: Int,
    val startHour: Int,
    val endHour: Int,
) {
    val level: Int get() = xp / 100 + 1
    val xpInLevel: Int get() = xp % 100

    fun pending(today: String = Days.today()): List<Task> = tasks.filter { !it.isDone(today) }

    /** Um dia sem fechar não zera. Dois dias seguidos sem fechar zeram. */
    fun displayStreak(today: String = Days.today()): Int {
        if (lastClosedDay.isEmpty()) return 0
        return if (Days.between(lastClosedDay, today) >= 3) 0 else streak
    }
}

data class CompleteResult(
    val leveledUp: Boolean,
    val newLevel: Int,
    val dayClosed: Boolean,
    val streak: Int,
)

object Days {
    fun today(): String = LocalDate.now().toString()

    fun between(a: String, b: String): Long = try {
        ChronoUnit.DAYS.between(LocalDate.parse(a), LocalDate.parse(b))
    } catch (e: Exception) {
        999L
    }
}

object Repo {
    private val K_TASKS = stringPreferencesKey("tasks")
    private val K_XP = intPreferencesKey("xp")
    private val K_STREAK = intPreferencesKey("streak")
    private val K_LAST = stringPreferencesKey("last_closed")
    private val K_INTERVAL = intPreferencesKey("interval")
    private val K_START = intPreferencesKey("start")
    private val K_END = intPreferencesKey("end")

    const val XP_PER_TASK = 10

    private val defaultTasks = listOf(
        Task(1, "Escovar o dente", "Só pasta e 30 segundos"),
        Task(2, "Lavar o rosto e hidratar", "Só água no rosto"),
        Task(3, "Beber água", "Um copo, só isso"),
        Task(4, "Café da manhã", "Uma fruta ou um pão"),
        Task(5, "Lanche", "Qualquer coisa rápida"),
        Task(6, "Separar a roupa de amanhã", "Só a camiseta em cima da cadeira"),
        Task(7, "Treino de 10 minutos", "10 polichinelos"),
    )

    private fun decode(s: String?): List<Task> {
        if (s == null) return defaultTasks
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                Task(
                    id = o.getLong("id"),
                    name = o.getString("name"),
                    minimal = o.optString("min", ""),
                    doneDay = o.optString("day", ""),
                    doneMinimal = o.optBoolean("dmin", false),
                )
            }
        } catch (e: Exception) {
            defaultTasks
        }
    }

    private fun encode(list: List<Task>): String {
        val a = JSONArray()
        for (t in list) {
            val o = JSONObject()
            o.put("id", t.id)
            o.put("name", t.name)
            o.put("min", t.minimal)
            o.put("day", t.doneDay)
            o.put("dmin", t.doneMinimal)
            a.put(o)
        }
        return a.toString()
    }

    private fun parse(p: Preferences) = AppState(
        tasks = decode(p[K_TASKS]),
        xp = p[K_XP] ?: 0,
        streak = p[K_STREAK] ?: 0,
        lastClosedDay = p[K_LAST] ?: "",
        intervalHours = p[K_INTERVAL] ?: 3,
        startHour = p[K_START] ?: 8,
        endHour = p[K_END] ?: 23,
    )

    fun flow(ctx: Context): Flow<AppState> = ctx.dataStore.data.map { parse(it) }

    suspend fun get(ctx: Context): AppState = flow(ctx).first()

    suspend fun complete(ctx: Context, id: Long, minimal: Boolean): CompleteResult? {
        var result: CompleteResult? = null
        ctx.dataStore.edit { p ->
            val st = parse(p)
            val today = Days.today()
            val task = st.tasks.find { it.id == id } ?: return@edit
            if (task.isDone(today)) return@edit

            val tasks = st.tasks.map {
                if (it.id == id) it.copy(doneDay = today, doneMinimal = minimal) else it
            }
            val oldLevel = st.level
            val xp = st.xp + XP_PER_TASK
            p[K_TASKS] = encode(tasks)
            p[K_XP] = xp

            var closed = false
            var streak = st.displayStreak(today)
            if (tasks.all { it.isDone(today) } && st.lastClosedDay != today) {
                closed = true
                streak = if (st.lastClosedDay.isEmpty() || Days.between(st.lastClosedDay, today) >= 3) {
                    1
                } else {
                    st.streak + 1
                }
                p[K_STREAK] = streak
                p[K_LAST] = today
            }
            val newLevel = xp / 100 + 1
            result = CompleteResult(newLevel > oldLevel, newLevel, closed, streak)
        }
        return result
    }

    suspend fun undo(ctx: Context, id: Long) {
        ctx.dataStore.edit { p ->
            val st = parse(p)
            val today = Days.today()
            val task = st.tasks.find { it.id == id } ?: return@edit
            if (!task.isDone(today)) return@edit
            p[K_TASKS] = encode(st.tasks.map { if (it.id == id) it.copy(doneDay = "", doneMinimal = false) else it })
            p[K_XP] = (st.xp - XP_PER_TASK).coerceAtLeast(0)
        }
    }

    suspend fun add(ctx: Context, name: String, minimal: String) {
        ctx.dataStore.edit { p ->
            val st = parse(p)
            p[K_TASKS] = encode(st.tasks + Task(System.currentTimeMillis(), name, minimal))
        }
    }

    suspend fun remove(ctx: Context, id: Long) {
        ctx.dataStore.edit { p ->
            val st = parse(p)
            p[K_TASKS] = encode(st.tasks.filter { it.id != id })
        }
    }

    suspend fun saveSettings(ctx: Context, interval: Int, start: Int, end: Int) {
        val s = start.coerceIn(0, 23)
        ctx.dataStore.edit { p ->
            p[K_INTERVAL] = interval.coerceIn(1, 12)
            p[K_START] = s
            p[K_END] = end.coerceIn(s + 1, 24)
        }
    }
}
