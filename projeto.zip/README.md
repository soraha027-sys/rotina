# Rotina — avatar que cobra tarefas

App Android (Kotlin + Jetpack Compose, minSdk 26). 100% local, sem internet.

## Subir no GitHub pelo celular
1. github.com → **+** → **New repository** → nome `rotina` → **Create**.
2. No repositório: **Add file → Upload files** → escolha `projeto.zip` → **Commit changes**.
3. **Add file → Create new file** → nome: `.github/workflows/build.yml` → cole o conteúdo do workflow → **Commit changes**.
4. Aba **Actions** → espere o ✅ (uns 5–8 min).
5. Baixe o APK em: `https://github.com/SEU_USUARIO/rotina/releases/latest/download/app-debug.apk`

Para atualizar: suba um `projeto.zip` novo (mesmo nome, substitui) e baixe de novo. Instala por cima sem perder dados.

## Instalar
1. Abra o `app-debug.apk` baixado → permita "instalar apps desconhecidos" pro navegador → **Instalar**.
2. Se o Play Protect avisar: **Mais detalhes → Instalar mesmo assim**.
3. Abra o app e libere as 4 permissões na tela inicial.
4. Se alguma aparecer como "Configuração restrita": Configurações → Apps → Rotina → ⋮ → **Permitir configurações restritas**, e tente de novo.
5. Xiaomi/Samsung/Motorola: em Apps → Rotina → Bateria, marque **Sem restrições**; na Xiaomi, ligue também **Início automático**.
6. Ajustes (⚙️) → **Testar cobrança agora** pra ver o avatar.
