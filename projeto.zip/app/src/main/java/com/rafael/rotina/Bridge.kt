package com.rafael.rotina

import android.app.AlarmManager
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** Estado salvo como um JSON só (o mesmo que o app web usa). */
object Store {
    private const val PREFS = "rotina"
    private const val KEY = "state"

    fun load(ctx: Context): String =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""

    fun save(ctx: Context, json: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply()
    }

    private fun obj(ctx: Context): JSONObject? = try {
        val s = load(ctx)
        if (s.isBlank()) null else JSONObject(s)
    } catch (e: Exception) {
        null
    }

    data class Info(val pending: Int, val level: Int, val interval: Int, val start: Int, val end: Int, val headOn: Boolean = true)

    fun info(ctx: Context): Info {
        val o = obj(ctx) ?: return Info(pending = 7, level = 1, interval = 3, start = 8, end = 23)
        val today = LocalDate.now().toString()
        val tasks = o.optJSONArray("tasks") ?: JSONArray()
        var pending = 0
        for (i in 0 until tasks.length()) {
            val t = tasks.optJSONObject(i) ?: continue
            if (t.optString("day", "") != today) pending++
        }
        return Info(
            pending = pending,
            level = o.optInt("xp", 0) / 100 + 1,
            interval = o.optInt("interval", 3).coerceIn(1, 12),
            start = o.optInt("start", 8).coerceIn(0, 23),
            end = o.optInt("end", 23).coerceIn(1, 24),
            headOn = o.optBoolean("headOn", true),
        )
    }
}

/** O que cada tela (app ou janela flutuante) sabe fazer quando o JS pede. */
interface BridgeHost {
    fun openPerm(key: String) {}
    fun theme(dark: Boolean) {}
    fun overlayClose() {}
    fun overlayDismiss() {}
    fun overlayMinimize(mini: Boolean) {}
    fun overlayDrag(dx: Double, dy: Double) {}
    fun overlayDragEnd() {}
}

/** Exposto pro JavaScript como window.RotinaNative */
class Bridge(private val ctx: Context, private val host: BridgeHost, private val fromOverlay: Boolean) {
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun load(): String = Store.load(ctx)

    @JavascriptInterface
    fun save(json: String) {
        Store.save(ctx, json)
        ReminderService.send(ctx, if (fromOverlay) ReminderService.ACTION_SAVED_OVERLAY else ReminderService.ACTION_REFRESH)
    }

    @JavascriptInterface
    fun vibrate(pattern: String) {
        try {
            val a = JSONArray(pattern)
            val p = LongArray(a.length() + 1)
            p[0] = 0
            for (i in 0 until a.length()) p[i + 1] = a.optLong(i, 20)
            val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            v?.vibrate(VibrationEffect.createWaveform(p, -1))
        } catch (e: Exception) {
            // sem vibração
        }
    }

    @JavascriptInterface
    fun perms(): String {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pm = ctx.getSystemService(PowerManager::class.java)
        return JSONObject()
            .put("overlay", Settings.canDrawOverlays(ctx))
            .put("notif", NotificationManagerCompat.from(ctx).areNotificationsEnabled())
            .put("alarm", Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            .put("battery", pm.isIgnoringBatteryOptimizations(ctx.packageName))
            .toString()
    }

    @JavascriptInterface
    fun openPerm(key: String) {
        main.post { host.openPerm(key) }
    }

    @JavascriptInterface
    fun testNag() {
        ReminderService.send(ctx, ReminderService.ACTION_TEST)
    }

    @JavascriptInterface
    fun clipboard(): String = try {
        val cm = ctx.getSystemService(ClipboardManager::class.java)
        cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString() ?: ""
    } catch (e: Exception) {
        ""
    }

    @JavascriptInterface
    fun theme(mode: String) {
        main.post { host.theme(mode == "dark") }
    }

    @JavascriptInterface
    fun overlayClose() {
        main.post { host.overlayClose() }
    }

    @JavascriptInterface
    fun overlayDismiss() {
        main.post { host.overlayDismiss() }
    }

    @JavascriptInterface
    fun overlayMinimize(mini: Boolean) {
        main.post { host.overlayMinimize(mini) }
    }

    @JavascriptInterface
    fun overlayDragEnd() {
        main.post { host.overlayDragEnd() }
    }

    @JavascriptInterface
    fun overlayDrag(dx: Double, dy: Double) {
        main.post { host.overlayDrag(dx, dy) }
    }
}
