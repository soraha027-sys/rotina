package com.rafael.rotina

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

/** Serviço em primeiro plano: mantém o app vivo, agenda as cobranças e mostra a cabecinha do gato por cima dos outros apps. */
class ReminderService : Service(), BridgeHost {

    companion object {
        const val ACTION_START = "com.rafael.rotina.START"
        const val ACTION_TEST = "com.rafael.rotina.TEST"
        const val ACTION_REFRESH = "com.rafael.rotina.REFRESH"
        const val ACTION_SAVED_OVERLAY = "com.rafael.rotina.SAVED_OVERLAY"
        const val ACTION_APP_SHOWN = "com.rafael.rotina.APP_SHOWN"
        const val ACTION_APP_HIDDEN = "com.rafael.rotina.APP_HIDDEN"

        /** O app está aberto na tela? Aí o gato fica só dentro dele. */
        @Volatile
        var appVisible = false

        /** Avisos de dentro do app: o serviço já está rodando, então startService basta. */
        fun ping(ctx: Context, action: String) {
            try {
                ctx.startService(Intent(ctx, ReminderService::class.java).setAction(action))
            } catch (e: Exception) {
                send(ctx, action)
            }
        }

        private const val CH_SERVICE = "servico"
        private const val CH_REMIND = "cobranca"
        private const val ID_SERVICE = 1
        private const val ID_REMIND = 2

        /** Se a cabecinha fica na tela sem resposta, ela pula de novo a cada 15 min. */
        private const val NUDGE_MIN = 15L
        /** Fechou a cabecinha: ela volta em 3 min. */
        private const val BACK_MIN = 3L

        fun send(ctx: Context, action: String) {
            val i = Intent(ctx, ReminderService::class.java).setAction(action)
            try {
                ContextCompat.startForegroundService(ctx, i)
            } catch (e: Exception) {
                Log.e("Rotina", "Não consegui iniciar o serviço", e)
            }
        }
    }

    private var web: WebView? = null
    private var params: WindowManager.LayoutParams? = null
    private var mini = true
    private var headX = -1
    private var dragActive = false
    private var headY = -1
    private var snapAnim: android.animation.ValueAnimator? = null
    private var lastText = "Rotina ativa"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startFg()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        handle(intent?.action ?: ACTION_START)
        return START_STICKY
    }

    override fun onDestroy() {
        hideOverlay()
        super.onDestroy()
    }

    private fun handle(action: String) {
        val info = Store.info(this)
        val inWindow = Scheduler.inWindow(LocalDateTime.now(), info.start, info.end)
        when (action) {
            ACTION_APP_SHOWN -> {
                appVisible = true
                hideOverlay()
            }
            ACTION_APP_HIDDEN -> {
                appVisible = false
                if (info.headOn && inWindow && info.pending > 0) showOverlay()
            }
            Scheduler.ACTION_CHECK -> if (!appVisible && inWindow && info.pending > 0) showOverlay()
            Scheduler.ACTION_SNOOZE -> {
                if (appVisible) {
                    Unit
                } else if (info.pending == 0 || !inWindow) {
                    hideOverlay()
                } else if (web != null) {
                    web?.evaluateJavascript("window.nudge&&window.nudge()", null)
                    Scheduler.scheduleSnooze(this, NUDGE_MIN)
                } else {
                    showOverlay()
                }
            }
            ACTION_TEST -> {
                if (info.pending == 0) {
                    Toast.makeText(this, "Nada pendente hoje!", Toast.LENGTH_SHORT).show()
                } else {
                    hideOverlay()
                    showOverlay()
                }
            }
            ACTION_REFRESH -> web?.evaluateJavascript("window.ovCheck&&window.ovCheck()", null)
            ACTION_SAVED_OVERLAY -> Unit
        }
        updateNotification(info, Scheduler.scheduleNext(this, info))
    }

    // ---------- janela por cima dos outros apps ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface", "ClickableViewAccessibility")
    private fun showOverlay() {
        if (web != null) {
            web?.evaluateJavascript("window.nudge&&window.nudge()", null)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            postFallback()
            return
        }
        val wm = getSystemService(WindowManager::class.java)
        val p = WindowManager.LayoutParams(
            dp(96), dp(96),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = resources.displayMetrics.widthPixels - dp(96) - dp(6)
        p.y = (resources.displayMetrics.heightPixels * 0.35).roundToInt()
        val w = WebView(this)
        w.setBackgroundColor(Color.TRANSPARENT)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.settings.textZoom = 100
        w.addJavascriptInterface(Bridge(applicationContext, this, fromOverlay = true), "RotinaNative")
        w.webViewClient = WebViewClient()
        // arrasto nativo: usa a posição real do dedo na tela (rawX/rawY), então não trava
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var sx = 0
        var sy = 0
        var dragging = false
        w.setOnTouchListener { v, ev ->
            val q = params ?: return@setOnTouchListener false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    sx = q.x
                    sy = q.y
                    dragging = false
                    snapAnim?.cancel()
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX
                    val dy = ev.rawY - downY
                    if (!dragging && (mini || ev.y < dp(44)) && Math.hypot(dx.toDouble(), dy.toDouble()) > slop) {
                        dragging = true
                        dragActive = true
                        val c = MotionEvent.obtain(ev)
                        c.action = MotionEvent.ACTION_CANCEL
                        v.onTouchEvent(c)
                        c.recycle()
                    }
                    if (dragging) {
                        q.x = (sx + dx).roundToInt()
                        q.y = (sy + dy).roundToInt()
                        relayout()
                        true
                    } else {
                        false
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        dragActive = false
                        overlayDragEnd()
                        true
                    } else {
                        false
                    }
                }
                else -> false
            }
        }
        try {
            wm.addView(w, p)
            web = w
            params = p
            mini = true
            headX = p.x
            headY = p.y
            w.loadUrl("file:///android_asset/www/index.html#overlay")
            vibrate()
            Scheduler.scheduleSnooze(this, NUDGE_MIN)
        } catch (e: Exception) {
            Log.e("Rotina", "Não consegui mostrar o gato", e)
            w.destroy()
        }
    }

    private fun hideOverlay() {
        snapAnim?.cancel()
        val w = web ?: return
        try {
            getSystemService(WindowManager::class.java).removeView(w)
        } catch (e: Exception) {
            Log.w("Rotina", "removeView", e)
        }
        w.destroy()
        web = null
        params = null
    }

    private fun vibrate() {
        Bridge(applicationContext, this, true).vibrate("[40,60,40]")
    }

    private fun relayout() {
        val w = web ?: return
        val p = params ?: return
        try {
            getSystemService(WindowManager::class.java).updateViewLayout(w, p)
        } catch (e: Exception) {
            Log.w("Rotina", "updateViewLayout", e)
        }
    }

    // pedidos do JavaScript da janela flutuante
    override fun overlayClose() {
        hideOverlay()
        Scheduler.cancelSnooze(this)
        val info = Store.info(this)
        updateNotification(info, Scheduler.scheduleNext(this, info))
    }

    override fun overlayDismiss() {
        hideOverlay()
        Scheduler.scheduleSnooze(this, BACK_MIN)
    }

    override fun overlayMinimize(mini: Boolean) {
        val p = params ?: return
        if (dragActive && !mini) return
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        snapAnim?.cancel()
        if (!mini && this.mini) {
            // guarda onde a cabecinha estava e abre o cartão do lado dela, sem sair da tela
            headX = p.x
            headY = p.y
            val onRight = p.x + dp(48) > sw / 2
            p.width = dp(310)
            p.height = dp(470)
            p.x = if (onRight) p.x + dp(96) - p.width else p.x
            p.y = p.y - dp(40)
        } else if (mini) {
            p.width = dp(96)
            p.height = dp(96)
            if (headX >= 0) {
                p.x = headX
                p.y = headY
            }
        }
        this.mini = mini
        p.x = p.x.coerceIn(0, (sw - p.width).coerceAtLeast(0))
        p.y = p.y.coerceIn(0, (sh - p.height).coerceAtLeast(0))
        relayout()
    }

    /** Soltou o arrasto: a cabecinha desliza até a borda mais próxima. */
    override fun overlayDragEnd() {
        val p = params ?: return
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        p.y = p.y.coerceIn(0, (sh - p.height).coerceAtLeast(0))
        if (!mini) {
            relayout()
            return
        }
        val target = if (p.x + p.width / 2 > sw / 2) sw - p.width - dp(6) else dp(6)
        snapAnim?.cancel()
        snapAnim = android.animation.ValueAnimator.ofInt(p.x, target).apply {
            duration = 280
            interpolator = android.view.animation.OvershootInterpolator(1.2f)
            addUpdateListener {
                val q = params ?: return@addUpdateListener
                q.x = it.animatedValue as Int
                relayout()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    headX = params?.x ?: -1
                    headY = params?.y ?: -1
                }
            })
            start()
        }
    }

    override fun overlayDrag(dx: Double, dy: Double) {
        val p = params ?: return
        val d = resources.displayMetrics.density
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        p.x = (p.x + dx * d).roundToInt().coerceIn(-p.width / 3, sw - p.width * 2 / 3)
        p.y = (p.y + dy * d).roundToInt().coerceIn(0, (sh - p.height).coerceAtLeast(0))
        relayout()
    }

    // ---------- notificações ----------

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Serviço da rotina", NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false)
            },
        )
        nm.createNotificationChannel(NotificationChannel(CH_REMIND, "Cobranças", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun buildNotif(text: String): Notification =
        NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Rotina ativa")
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(openAppIntent())
            .build()

    private fun startFg() {
        val n = buildNotif(lastText)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(ID_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(ID_SERVICE, n)
            }
        } catch (e: Exception) {
            Log.e("Rotina", "startForeground falhou", e)
        }
    }

    private fun updateNotification(info: Store.Info, next: LocalDateTime) {
        val hora = next.format(DateTimeFormatter.ofPattern("HH:mm"))
        lastText = if (info.pending == 0) {
            "Tudo feito hoje · Nível ${info.level}"
        } else {
            "${info.pending} pendente(s) · Nível ${info.level} · próxima cobrança $hora"
        }
        try {
            getSystemService(NotificationManager::class.java).notify(ID_SERVICE, buildNotif(lastText))
        } catch (e: SecurityException) {
            Log.w("Rotina", "Sem permissão de notificação", e)
        }
    }

    /** Sem permissão de sobreposição: avisa por notificação. */
    private fun postFallback() {
        val n = NotificationCompat.Builder(this, CH_REMIND)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Tem tarefa te esperando")
            .setContentText("Libere \"Exibir sobre outros apps\" pra o gato aparecer na tela.")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openAppIntent())
            .build()
        try {
            getSystemService(NotificationManager::class.java).notify(ID_REMIND, n)
        } catch (e: SecurityException) {
            Log.w("Rotina", "Sem permissão de notificação", e)
        }
    }
}
