package com.rafael.rotina

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RotinaTheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    App(resumeTick)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
        ReminderService.send(this, ReminderService.ACTION_START)
    }
}

// ---------------- Permissões ----------------

object Perms {
    fun overlay(ctx: Context) = Settings.canDrawOverlays(ctx)

    fun notifications(ctx: Context) = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun exactAlarms(ctx: Context) = Build.VERSION.SDK_INT < 31 ||
        ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    fun battery(ctx: Context) =
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

    fun all(ctx: Context) = overlay(ctx) && notifications(ctx) && exactAlarms(ctx) && battery(ctx)
}

private fun Context.openSafe(primary: Intent, fallback: Intent? = null) {
    try {
        startActivity(primary)
    } catch (e: Exception) {
        if (fallback != null) {
            try {
                startActivity(fallback)
            } catch (e2: Exception) {
                // nada
            }
        }
    }
}

private fun Context.appDetails() =
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))

// ---------------- Tema ----------------

@Composable
fun RotinaTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(primary = Color(0xFF7FD8FF), secondary = Color(0xFFFFC857), tertiary = Color(0xFF2EC4B6))
    } else {
        lightColorScheme(primary = Color(0xFF2A6FDB), secondary = Color(0xFFF4A261), tertiary = Color(0xFF2EC4B6))
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun App(tick: Int) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("ui", Context.MODE_PRIVATE) }
    var onboarded by remember { mutableStateOf(prefs.getBoolean("onboarded", false)) }
    if (!onboarded) {
        PermissionScreen(tick) {
            prefs.edit().putBoolean("onboarded", true).apply()
            onboarded = true
            ReminderService.send(ctx, ReminderService.ACTION_START)
        }
    } else {
        HomeScreen(tick) { onboarded = false }
    }
}

// ---------------- Tela de permissões ----------------

@Composable
fun PermissionScreen(tick: Int, onContinue: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("ui", Context.MODE_PRIVATE) }
    var refresh by remember { mutableIntStateOf(0) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        refresh++
    }
    val key = tick + refresh
    val overlayOk = remember(key) { Perms.overlay(ctx) }
    val notifOk = remember(key) { Perms.notifications(ctx) }
    val alarmOk = remember(key) { Perms.exactAlarms(ctx) }
    val batteryOk = remember(key) { Perms.battery(ctx) }
    val pkg = Uri.parse("package:${ctx.packageName}")

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AvatarSprite(Mood.IDLE, 64.dp, 0)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Oi! Bora configurar?", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("4 liberações e eu começo a te cobrar (com carinho).", fontSize = 14.sp)
            }
        }
        PermRow("1. Exibir sobre outros apps", "Pra eu aparecer por cima de qualquer app.", overlayOk) {
            ctx.openSafe(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg), ctx.appDetails())
        }
        PermRow("2. Notificações", "Pra notificação fixa que me mantém vivo.", notifOk) {
            if (Build.VERSION.SDK_INT >= 33 && !prefs.getBoolean("asked_notif", false)) {
                prefs.edit().putBoolean("asked_notif", true).apply()
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                ctx.openSafe(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName),
                    ctx.appDetails(),
                )
            }
        }
        PermRow("3. Alarmes exatos", "Pra cobrar na hora certa.", alarmOk) {
            if (Build.VERSION.SDK_INT >= 31) {
                ctx.openSafe(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg), ctx.appDetails())
            }
        }
        PermRow("4. Ignorar otimização de bateria", "Pro Android não me matar.", batteryOk) {
            ctx.openSafe(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg),
                Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            )
        }
        Spacer(Modifier.weight(1f))
        val allOk = overlayOk && notifOk && alarmOk && batteryOk
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Text(if (allOk) "Começar 🚀" else "Continuar mesmo assim", fontSize = 18.sp)
        }
    }
}

@Composable
fun PermRow(title: String, why: String, ok: Boolean, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(why, fontSize = 13.sp)
            }
            if (ok) {
                Text("✅", fontSize = 24.sp)
            } else {
                Button(onClick = onClick) { Text("Liberar") }
            }
        }
    }
}

// ---------------- Tela principal ----------------

@Composable
fun HomeScreen(tick: Int, onReviewPerms: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val stateFlow = remember { Repo.flow(ctx) }
    val state: AppState? by stateFlow.collectAsState(initial = null)
    val today = remember(tick) { Days.today() }

    var confetti by remember { mutableIntStateOf(0) }
    var happy by remember { mutableStateOf(false) }
    var banner by remember { mutableStateOf<String?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var fullDay by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Task?>(null) }
    var avatarVer by remember { mutableIntStateOf(0) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && AvatarStore.save(ctx, uri)) {
            avatarVer++
            ReminderService.send(ctx, ReminderService.ACTION_REFRESH)
        }
    }

    LaunchedEffect(confetti) {
        if (confetti > 0) {
            happy = true
            delay(2500)
            happy = false
        }
    }

    val st = state
    if (st == null) {
        Box(Modifier.fillMaxSize())
        return
    }

    fun complete(t: Task, minimal: Boolean) {
        scope.launch {
            val r = Repo.complete(ctx, t.id, minimal)
            if (r != null) {
                confetti++
                Feedback.celebrate(ctx, r.dayClosed)
                banner = when {
                    r.dayClosed -> Msgs.FULL_DAY
                    r.leveledUp -> "Subiu pro nível ${r.newLevel}! ⭐"
                    else -> Msgs.win()
                }
                if (r.dayClosed) fullDay = true
            }
            ReminderService.send(ctx, ReminderService.ACTION_REFRESH)
        }
    }

    val pending = st.pending(today)
    val mood = when {
        happy -> Mood.HAPPY
        pending.isEmpty() -> Mood.HAPPY
        else -> Mood.IMPATIENT
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            floatingActionButton = {
                ExtendedFloatingActionButton(onClick = { showAdd = true }) {
                    Text("+ Tarefa", fontSize = 18.sp)
                }
            },
        ) { pad ->
            LazyColumn(
                Modifier.fillMaxSize().padding(pad),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    Header(st, today, mood, avatarVer) { showSettings = true }
                }
                if (!Perms.all(ctx)) {
                    item {
                        OutlinedButton(onClick = onReviewPerms, modifier = Modifier.fillMaxWidth()) {
                            Text("⚠️ Falta liberar permissões — toque aqui")
                        }
                    }
                }
                val b = banner
                if (b != null) {
                    item {
                        Card(
                            Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        ) {
                            Text(b, Modifier.padding(14.dp), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (st.tasks.isEmpty()) {
                    item { Text("Nenhuma tarefa. Toque em \"+ Tarefa\" pra criar.") }
                }
                items(st.tasks, key = { it.id }) { t ->
                    TaskCard(
                        t = t,
                        done = t.isDone(today),
                        onDone = { complete(t, false) },
                        onMin = { complete(t, true) },
                        onUndo = {
                            scope.launch {
                                Repo.undo(ctx, t.id)
                                ReminderService.send(ctx, ReminderService.ACTION_REFRESH)
                            }
                        },
                        onDelete = { toDelete = t },
                    )
                }
                item { Spacer(Modifier.height(90.dp)) }
            }
        }
        ConfettiLayer(confetti)
    }

    if (showAdd) {
        AddDialog(onDismiss = { showAdd = false }) { name, min ->
            showAdd = false
            scope.launch { Repo.add(ctx, name, min) }
        }
    }

    val del = toDelete
    if (del != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Remover tarefa?") },
            text = { Text(del.name) },
            confirmButton = {
                TextButton(onClick = {
                    toDelete = null
                    scope.launch {
                        Repo.remove(ctx, del.id)
                        ReminderService.send(ctx, ReminderService.ACTION_REFRESH)
                    }
                }) { Text("Remover") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } },
        )
    }

    if (fullDay) {
        AlertDialog(
            onDismissRequest = { fullDay = false },
            title = { Text("🏆 Dia fechado!") },
            text = {
                Text("Você fez TODAS as tarefas de hoje. Sequência: ${st.displayStreak(today)} dia(s). Orgulho demais!")
            },
            confirmButton = { TextButton(onClick = { fullDay = false }) { Text("Bora! 🎉") } },
        )
    }

    if (showSettings) {
        SettingsDialog(
            st = st,
            onDismiss = { showSettings = false },
            onSave = { i, s, e ->
                showSettings = false
                scope.launch {
                    Repo.saveSettings(ctx, i, s, e)
                    ReminderService.send(ctx, ReminderService.ACTION_START)
                }
            },
            onPickAvatar = { picker.launch("image/*") },
            onDefaultAvatar = {
                AvatarStore.clear(ctx)
                avatarVer++
                ReminderService.send(ctx, ReminderService.ACTION_REFRESH)
            },
            onTest = {
                showSettings = false
                ReminderService.send(ctx, ReminderService.ACTION_TEST)
            },
            onPerms = {
                showSettings = false
                onReviewPerms()
            },
        )
    }
}

@Composable
fun Header(st: AppState, today: String, mood: Mood, avatarVer: Int, onSettings: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            AvatarSprite(mood, 80.dp, avatarVer)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Nível ${st.level}", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { st.xpInLevel / 100f },
                    modifier = Modifier.fillMaxWidth().height(12.dp),
                )
                Text("${st.xpInLevel}/100 XP", fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                Text("🔥 ${st.displayStreak(today)} dia(s) de sequência", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
            TextButton(onClick = onSettings) { Text("⚙️", fontSize = 22.sp) }
        }
    }
}

@Composable
fun TaskCard(
    t: Task,
    done: Boolean,
    onDone: () -> Unit,
    onMin: () -> Unit,
    onUndo: () -> Unit,
    onDelete: () -> Unit,
) {
    val container = if (done) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.surfaceVariant
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = container)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    t.name,
                    Modifier.weight(1f),
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    textDecoration = if (done) TextDecoration.LineThrough else null,
                )
                TextButton(onClick = onDelete) { Text("✕") }
            }
            Text("Mínimo: ${t.minimal}", fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            if (!done) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onDone, modifier = Modifier.weight(1f).height(58.dp)) {
                        Text("✓ Feito", fontSize = 18.sp)
                    }
                    OutlinedButton(onClick = onMin, modifier = Modifier.weight(1f).height(58.dp)) {
                        Text("½ Mínima", fontSize = 18.sp)
                    }
                }
            } else {
                OutlinedButton(onClick = onUndo, modifier = Modifier.fillMaxWidth()) {
                    Text(if (t.doneMinimal) "✓ Feito (mínima) · desfazer" else "✓ Feito · desfazer")
                }
            }
        }
    }
}

@Composable
fun AddDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var min by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nova tarefa") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Tarefa") }, singleLine = true)
                OutlinedTextField(value = min, onValueChange = { min = it }, label = { Text("Versão mínima") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = { onAdd(name.trim(), min.trim().ifBlank { "Fazer só um pouquinho" }) },
            ) { Text("Adicionar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

@Composable
fun SettingsDialog(
    st: AppState,
    onDismiss: () -> Unit,
    onSave: (Int, Int, Int) -> Unit,
    onPickAvatar: () -> Unit,
    onDefaultAvatar: () -> Unit,
    onTest: () -> Unit,
    onPerms: () -> Unit,
) {
    var interval by remember { mutableStateOf(st.intervalHours.toString()) }
    var start by remember { mutableStateOf(st.startHour.toString()) }
    var end by remember { mutableStateOf(st.endHour.toString()) }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ajustes") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = interval, onValueChange = { interval = it },
                    label = { Text("Cobrar a cada (horas)") }, singleLine = true, keyboardOptions = num,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = start, onValueChange = { start = it }, modifier = Modifier.weight(1f),
                        label = { Text("Das (h)") }, singleLine = true, keyboardOptions = num,
                    )
                    OutlinedTextField(
                        value = end, onValueChange = { end = it }, modifier = Modifier.weight(1f),
                        label = { Text("Até (h)") }, singleLine = true, keyboardOptions = num,
                    )
                }
                Text("Se ignorar, volto a cada 15 min.", fontSize = 12.sp)
                OutlinedButton(onClick = onPickAvatar, modifier = Modifier.fillMaxWidth()) { Text("Trocar avatar (PNG)") }
                OutlinedButton(onClick = onDefaultAvatar, modifier = Modifier.fillMaxWidth()) { Text("Voltar ao avatar padrão") }
                OutlinedButton(onClick = onTest, modifier = Modifier.fillMaxWidth()) { Text("Testar cobrança agora") }
                OutlinedButton(onClick = onPerms, modifier = Modifier.fillMaxWidth()) { Text("Revisar permissões") }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    interval.toIntOrNull() ?: st.intervalHours,
                    start.toIntOrNull() ?: st.startHour,
                    end.toIntOrNull() ?: st.endHour,
                )
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } },
    )
}

// ---------------- Avatar e confete (Compose) ----------------

@Composable
fun AvatarSprite(mood: Mood, dim: Dp, version: Int) {
    val ctx = LocalContext.current
    val bmp = remember(version) { AvatarStore.load(ctx)?.asImageBitmap() }
    val transition = rememberInfiniteTransition(label = "avatar")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing)),
        label = "t",
    )
    val wave = sin(t * 2 * PI).toFloat()
    val dy = when (mood) {
        Mood.HAPPY -> -abs(sin(t * 2 * PI)).toFloat() * 12f
        else -> wave * 2f
    }
    val dx = if (mood == Mood.IMPATIENT) sin(t * 8 * PI).toFloat() * 2f else 0f

    Box(Modifier.size(dim).offset(x = dx.dp, y = dy.dp)) {
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = "Avatar",
                modifier = Modifier.fillMaxSize(),
                filterQuality = FilterQuality.None,
            )
        } else {
            val rows = Sprites.forMood(mood)
            Canvas(Modifier.fillMaxSize()) {
                val px = size.minDimension / 16f
                rows.forEachIndexed { y, row ->
                    row.forEachIndexed { x, ch ->
                        val c = Sprites.color(ch)
                        if (c != null) {
                            drawRect(
                                color = Color(c),
                                topLeft = Offset(x * px, y * px),
                                size = Size(px + 0.5f, px + 0.5f),
                            )
                        }
                    }
                }
            }
        }
    }
}

private class CParticle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    val color: Color, val s: Float, var r: Float, val vr: Float,
)

@Composable
fun ConfettiLayer(trigger: Int) {
    val parts = remember { mutableListOf<CParticle>() }
    var frame by remember { mutableLongStateOf(0L) }
    val colors = listOf(
        Color(0xFFFFC857), Color(0xFFE63946), Color(0xFF2EC4B6),
        Color(0xFF5BC0EB), Color(0xFF9B5DE5), Color(0xFFFF8FAB),
    )
    LaunchedEffect(trigger) {
        if (trigger == 0) return@LaunchedEffect
        repeat(120) {
            parts.add(
                CParticle(
                    x = 0.5f + (Random.nextFloat() - 0.5f) * 0.2f,
                    y = 0.3f,
                    vx = (Random.nextFloat() - 0.5f) * 1.2f,
                    vy = -(Random.nextFloat() * 0.9f + 0.3f),
                    color = colors[Random.nextInt(colors.size)],
                    s = 6f + Random.nextFloat() * 6f,
                    r = Random.nextFloat() * 360f,
                    vr = (Random.nextFloat() - 0.5f) * 720f,
                ),
            )
        }
        var last = withFrameMillis { it }
        while (parts.isNotEmpty()) {
            val now = withFrameMillis { it }
            val dt = (now - last).coerceAtMost(50L) / 1000f
            last = now
            val iter = parts.iterator()
            while (iter.hasNext()) {
                val p = iter.next()
                p.vy += 1.3f * dt
                p.x += p.vx * dt
                p.y += p.vy * dt
                p.r += p.vr * dt
                if (p.y > 1.1f) iter.remove()
            }
            frame = now
        }
        frame = 0L
    }
    Canvas(Modifier.fillMaxSize()) {
        if (frame < 0L) return@Canvas
        for (p in parts) {
            val cx = p.x * size.width
            val cy = p.y * size.height
            val s = p.s * density
            rotate(degrees = p.r, pivot = Offset(cx, cy)) {
                drawRect(color = p.color, topLeft = Offset(cx - s / 2, cy - s / 3), size = Size(s, s * 0.66f))
            }
        }
    }
}
