package com.rafael.rotina

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import java.time.LocalDateTime
import java.time.ZoneId

object Scheduler {
    const val ACTION_CHECK = "com.rafael.rotina.CHECK"
    const val ACTION_SNOOZE = "com.rafael.rotina.SNOOZE"

    private const val RC_CHECK = 1001
    private const val RC_SNOOZE = 1002

    /** Horários de cobrança: início, início+intervalo, ... até o fim da janela. */
    fun nextSlot(now: LocalDateTime, interval: Int, start: Int, end: Int): LocalDateTime {
        var day = now.toLocalDate()
        repeat(3) {
            var h = start
            while (h <= end) {
                val t = if (h >= 24) day.atTime(23, 59) else day.atTime(h, 0)
                if (t.isAfter(now)) return t
                h += interval.coerceAtLeast(1)
            }
            day = day.plusDays(1)
        }
        return now.plusHours(interval.toLong())
    }

    fun inWindow(now: LocalDateTime, start: Int, end: Int): Boolean {
        val m = now.hour * 60 + now.minute
        return m >= start * 60 && m <= end * 60
    }

    private fun pending(ctx: Context, action: String, rc: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, rc,
            Intent(ctx, AlarmReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun setAlarm(ctx: Context, at: LocalDateTime, pi: PendingIntent) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val millis = at.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        try {
            val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
            if (exact) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
            }
        } catch (e: SecurityException) {
            Log.w("Rotina", "Sem alarme exato, usando aproximado", e)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
        }
    }

    fun scheduleNext(ctx: Context, info: Store.Info): LocalDateTime {
        val at = nextSlot(LocalDateTime.now(), info.interval, info.start, info.end)
        setAlarm(ctx, at, pending(ctx, ACTION_CHECK, RC_CHECK))
        return at
    }

    fun scheduleSnooze(ctx: Context, minutes: Long) {
        setAlarm(ctx, LocalDateTime.now().plusMinutes(minutes), pending(ctx, ACTION_SNOOZE, RC_SNOOZE))
    }

    fun cancelSnooze(ctx: Context) {
        ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, ACTION_SNOOZE, RC_SNOOZE))
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        ReminderService.send(context, action)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderService.send(context, ReminderService.ACTION_START)
    }
}
