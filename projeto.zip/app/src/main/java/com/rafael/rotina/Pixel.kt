package com.rafael.rotina

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.View
import java.io.File
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

enum class Mood { IDLE, SAD, IMPATIENT, HAPPY }

/** Avatar 16x16 desenhado por código. Cada letra é uma cor; '.' é transparente. */
object Sprites {
    private val top = listOf(
        "................",
        ".....KKKKKK.....",
        "...KKLLGGGGKK...",
        "..KLLGGGGGGGGK..",
        ".KLGGGGGGGGGGGK.",
    )
    private val bottom = listOf(
        ".KGGGGGGGGGGGGK.",
        "..KKGGGGGGGGKK..",
        "...KKK....KKK...",
        "................",
    )
    private val idle = listOf(
        ".KGGGGGGGGGGGGK.",
        "KGGGWBGGGGWBGGGK",
        "KGGGWBGGGGWBGGGK",
        "KGPPGGGGGGGGPPGK",
        "KGGGGKGGGGKGGGGK",
        "KGGGGGKKKKGGGGGK",
        ".KGGGGGGGGGGGGK.",
    )
    private val happy = listOf(
        ".KGGKGGGGGGKGGK.",
        "KGGKGKGGGGKGKGGK",
        "KGGGGGGGGGGGGGGK",
        "KGPPGKKKKKKGPPGK",
        "KGGGGKRRRRKGGGGK",
        "KGGGGGKRRKGGGGGK",
        ".KGGGGGKKGGGGGK.",
    )
    private val sad = listOf(
        ".KGKKGGGGGGKKGK.",
        "KGGGWBGGGGBWGGGK",
        "KGGGWBGGGGBWGGGK",
        "KGGGGGGGGGGGTGGK",
        "KGGGGGKKKKGGTGGK",
        "KGGGGKGGGGKGGGGK",
        ".KGGGGGGGGGGGGK.",
    )
    private val impatient = listOf(
        ".KGGGGGGGGGGGGK.",
        "KGGKKKGGGGKKKGGK",
        "KGGWBWGGGGWBWGGK",
        "KGGGGGGGGGGGGGGK",
        "KGGGGGGGGGGGGGGK",
        "KGGGGKKKKKKGGGGK",
        ".KGGGGGGGGGGGGK.",
    )

    fun forMood(m: Mood): List<String> = when (m) {
        Mood.IDLE -> top + idle + bottom
        Mood.HAPPY -> top + happy + bottom
        Mood.SAD -> top + sad + bottom
        Mood.IMPATIENT -> {
            val t = top.toMutableList()
            t[3] = "..KLLGGGGGGGGKT." // gota de suor
            t + impatient + bottom
        }
    }

    fun color(c: Char): Int? = when (c) {
        'K', 'B' -> 0xFF1B1B2F.toInt()
        'G' -> 0xFF5BC0EB.toInt()
        'L' -> 0xFFA8E6FF.toInt()
        'W' -> 0xFFFFFFFF.toInt()
        'P' -> 0xFFFF8FAB.toInt()
        'R' -> 0xFFE63946.toInt()
        'T' -> 0xFF4CC9F0.toInt()
        else -> null
    }

    fun draw(c: Canvas, rows: List<String>, left: Float, top: Float, px: Float, paint: Paint) {
        rows.forEachIndexed { y, row ->
            row.forEachIndexed { x, ch ->
                val col = color(ch)
                if (col != null) {
                    paint.color = col
                    c.drawRect(left + x * px, top + y * px, left + (x + 1) * px + 0.5f, top + (y + 1) * px + 0.5f, paint)
                }
            }
        }
    }
}

/** PNG próprio do usuário, salvo dentro do app. */
object AvatarStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "avatar.png")

    fun load(ctx: Context): Bitmap? {
        val f = file(ctx)
        if (!f.exists()) return null
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bounds)
            var sample = 1
            while (bounds.outWidth / sample > 512 || bounds.outHeight / sample > 512) sample *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        }
    }

    fun save(ctx: Context, uri: Uri): Boolean = try {
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            file(ctx).outputStream().use { input.copyTo(it) }
        }
        if (load(ctx) == null) {
            file(ctx).delete()
            false
        } else {
            true
        }
    } catch (e: Exception) {
        false
    }

    fun clear(ctx: Context) {
        file(ctx).delete()
    }
}

/** Avatar animado para a janela flutuante. */
class AvatarView(ctx: Context) : View(ctx) {
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
    private var custom: Bitmap? = AvatarStore.load(ctx)
    private var bounceUntil = 0L

    var mood: Mood = Mood.IDLE
        set(value) {
            field = value
            invalidate()
        }

    fun reload() {
        custom = AvatarStore.load(context)
        invalidate()
    }

    fun bounce() {
        bounceUntil = SystemClock.uptimeMillis() + 1200
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.uptimeMillis()
        val sec = (now % 100_000L) / 1000f
        val w = width.toFloat()
        val h = height.toFloat()
        val area = min(w, h) * 0.78f

        var dx = 0f
        var dy = 0f
        when (mood) {
            Mood.HAPPY -> dy = -abs(sin(sec * 9f)) * area * 0.22f
            Mood.IMPATIENT -> dx = sin(sec * 28f) * area * 0.035f
            Mood.SAD -> dy = sin(sec * 2f) * area * 0.025f
            Mood.IDLE -> dy = sin(sec * 3f) * area * 0.03f
        }
        if (now < bounceUntil) dy -= abs(sin(sec * 12f)) * area * 0.18f

        val left = (w - area) / 2f + dx
        val top = h - area + dy
        val bmp = custom
        if (bmp != null) {
            canvas.drawBitmap(bmp, null, RectF(left, top, left + area, top + area), paint)
        } else {
            Sprites.draw(canvas, Sprites.forMood(mood), left, top, area / 16f, paint)
        }
        if (isAttachedToWindow) postInvalidateOnAnimation()
    }
}

/** Confete simples para a janela flutuante. */
class ConfettiView(ctx: Context) : View(ctx) {
    private class P(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        val color: Int, val size: Float, var rot: Float, val vr: Float,
    )

    private val parts = mutableListOf<P>()
    private val paint = Paint()
    private var last = 0L
    private val colors = intArrayOf(
        0xFFFFC857.toInt(), 0xFFE63946.toInt(), 0xFF2EC4B6.toInt(),
        0xFF5BC0EB.toInt(), 0xFF9B5DE5.toInt(), 0xFFFF8FAB.toInt(),
    )

    fun burst(n: Int = 70) {
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height * 0.4f
        repeat(n) {
            parts.add(
                P(
                    x = cx, y = cy,
                    vx = (Random.nextFloat() - 0.5f) * 700f * d / 2f,
                    vy = -(Random.nextFloat() * 500f + 150f) * d / 2f,
                    color = colors[Random.nextInt(colors.size)],
                    size = (4f + Random.nextFloat() * 4f) * d,
                    rot = Random.nextFloat() * 360f,
                    vr = (Random.nextFloat() - 0.5f) * 720f,
                ),
            )
        }
        last = SystemClock.uptimeMillis()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (parts.isEmpty()) return
        val now = SystemClock.uptimeMillis()
        val dt = (now - last).coerceAtMost(50L) / 1000f
        last = now
        val g = 900f * resources.displayMetrics.density / 2f
        val it = parts.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.vy += g * dt
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.rot += p.vr * dt
            if (p.y > height + 40) {
                it.remove()
                continue
            }
            paint.color = p.color
            canvas.save()
            canvas.rotate(p.rot, p.x, p.y)
            canvas.drawRect(p.x - p.size / 2, p.y - p.size / 3, p.x + p.size / 2, p.y + p.size / 3, paint)
            canvas.restore()
        }
        if (parts.isNotEmpty()) postInvalidateOnAnimation()
    }
}

/** Som 8-bit gerado na hora (sem arquivo de áudio). */
object Chiptune {
    private val WIN = listOf(523.25f to 80, 659.25f to 80, 783.99f to 80, 1046.5f to 220)
    private val FANFARE = listOf(
        392f to 110, 523.25f to 110, 659.25f to 110, 783.99f to 200,
        659.25f to 110, 783.99f to 110, 1046.5f to 450,
    )

    fun play(bigDay: Boolean) {
        val notes = if (bigDay) FANFARE else WIN
        thread {
            try {
                val sr = 22050
                val totalMs = notes.sumOf { it.second }
                val total = totalMs * sr / 1000
                val buf = ShortArray(total)
                var idx = 0
                for ((f, ms) in notes) {
                    val n = ms * sr / 1000
                    val period = sr / f
                    for (i in 0 until n) {
                        if (idx >= total) break
                        val phase = (i % period) / period
                        val env = 1f - (i.toFloat() / n) * 0.7f
                        val v = if (phase < 0.5f) 1f else -1f
                        buf[idx++] = (v * env * 0.22f * Short.MAX_VALUE).toInt().toShort()
                    }
                }
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build(),
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build(),
                    )
                    .setBufferSizeInBytes(total * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                track.write(buf, 0, total)
                track.play()
                Thread.sleep(totalMs + 200L)
                track.release()
            } catch (e: Exception) {
                // sem som, segue o jogo
            }
        }
    }
}

object Feedback {
    private fun vibrate(ctx: Context, pattern: LongArray) {
        try {
            val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
                ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
            } else {
                ctx.getSystemService(Vibrator::class.java)
            }
            v?.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (e: Exception) {
            // ignora
        }
    }

    fun celebrate(ctx: Context, bigDay: Boolean) {
        Chiptune.play(bigDay)
        vibrate(ctx, if (bigDay) longArrayOf(0, 80, 60, 80, 60, 200) else longArrayOf(0, 50, 50, 90))
    }

    fun nudge(ctx: Context) {
        vibrate(ctx, longArrayOf(0, 40, 90, 40))
    }
}

object Msgs {
    private val ask = listOf(
        "Bora só %s?",
        "Ei! Rapidinho: %s. Eu espero aqui 😄",
        "Pausa de 1 minuto pra %s?",
        "Psiu… %s. Versão mínima também vale!",
        "Missão do momento: %s. Topa?",
    )
    private val win = listOf(
        "Mandou bem! +10 XP 🎉",
        "Isso aí! Mais uma ✓",
        "Boa! Pequenas vitórias contam 💪",
        "Feito! Seu eu do futuro agradece 😎",
        "Arrasou! +10 XP ✨",
    )
    const val FULL_DAY = "DIA FECHADO! 🏆 Você fez tudo hoje. Orgulho!"

    fun ask(t: Task): String = ask.random().format(t.name.replaceFirstChar { it.lowercase() })

    fun win(): String = win.random()
}
