package com.rafael.rotina

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/** Serviço em primeiro plano: mantém o app vivo e controla o avatar flutuante. */
class ReminderService : Service() {

    companion object {
        const val ACTION_START = "com.rafael.rotina.START"
        const val ACTION_TEST = "com.rafael.rotina.TEST"
        const val ACTION_REFRESH = "com.rafael.rotina.REFRESH"

        private const val CH_SERVICE = "servico"
        private const val CH_REMIND = "cobranca"
        private const val ID_SERVICE = 1
        private const val ID_REMIND = 2

        fun send(ctx: Context, action: String) {
            val i = Intent(ctx, ReminderService::class.java).setAction(action)
            try {
                ContextCompat.startForegroundService(ctx, i)
            } catch (e: Exception) {
                Log.e("Rotina", "Não consegui iniciar o serviço", e)
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var overlay: OverlayController? = null
    private var lastText = "Rotina ativa"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startFg()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        val action = intent?.action ?: ACTION_START
        scope.launch { handle(action) }
        return START_STICKY
    }

    override fun onDestroy() {
        overlay?.hide()
        overlay = null
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun handle(action: String) {
        val st = Repo.get(this)
        val now = LocalDateTime.now()
        val inWindow = Scheduler.inWindow(now, st.startHour, st.endHour)
        when (action) {
            Scheduler.ACTION_CHECK -> if (inWindow) remind(st, repeat = false)
            Scheduler.ACTION_SNOOZE -> {
                if (st.pending().isEmpty() || !inWindow) hideOverlay() else remind(st, repeat = true)
            }
            ACTION_TEST -> {
                if (st.pending().isEmpty()) {
                    Toast.makeText(this, "Nada pendente hoje! 🎉", Toast.LENGTH_SHORT).show()
                } else {
                    remind(st, repeat = false)
                }
            }
            ACTION_REFRESH -> {
                val ov = overlay
                if (ov != null && ov.isShowing) {
                    val p = st.pending()
                    if (p.isEmpty()) {
                        hideOverlay()
                    } else if (p.none { it.id == ov.currentTaskId }) {
                        ov.show(p.first(), Msgs.ask(p.first()), Mood.IMPATIENT)
                    }
                }
            }
        }
        val next = Scheduler.scheduleNext(this, st)
        updateNotification(st, next)
    }

    private fun remind(st: AppState, repeat: Boolean) {
        val p = st.pending()
        if (p.isEmpty()) {
            hideOverlay()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            postFallback(p.first())
            return
        }
        val ov = overlay ?: OverlayController(this) { t, minimal -> onAnswer(t, minimal) }.also { overlay = it }
        val mood = if (repeat) Mood.SAD else Mood.IMPATIENT
        val current = p.firstOrNull { it.id == ov.currentTaskId }
        if (ov.isShowing && current != null) {
            ov.expandAndNudge(mood)
        } else {
            val t = p.first()
            ov.show(t, Msgs.ask(t), mood)
        }
        Feedback.nudge(this)
        Scheduler.scheduleSnooze(this)
    }

    private fun onAnswer(t: Task, minimal: Boolean) {
        scope.launch {
            val r = Repo.complete(this@ReminderService, t.id, minimal)
            Scheduler.cancelSnooze(this@ReminderService)
            Feedback.celebrate(this@ReminderService, r?.dayClosed == true)
            val text = when {
                r == null -> "Já tava feito! 😄"
                r.dayClosed -> Msgs.FULL_DAY
                r.leveledUp -> "Subiu pro nível ${r.newLevel}! ⭐ +10 XP"
                else -> Msgs.win()
            }
            val ov = overlay
            if (ov != null) ov.celebrate(text) { hideOverlay() } else hideOverlay()
            val st = Repo.get(this@ReminderService)
            updateNotification(st, Scheduler.scheduleNext(this@ReminderService, st))
        }
    }

    private fun hideOverlay() {
        overlay?.hide()
        overlay = null
        Scheduler.cancelSnooze(this)
    }

    // ---------- Notificações ----------

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Serviço da rotina", NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false)
            },
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_REMIND, "Cobranças", NotificationManager.IMPORTANCE_HIGH),
        )
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun buildNotif(text: String): Notification =
        NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Rotina ativa")
            .setContentText(text)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(openAppIntent())
            .build()

    private fun startFg() {
        val n = buildNotif(lastText)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(ID_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(ID_SERVICE, n)
            }
        } catch (e: Exception) {
            Log.e("Rotina", "startForeground falhou", e)
        }
    }

    private fun updateNotification(st: AppState, next: LocalDateTime) {
        val p = st.pending().size
        val hora = next.format(DateTimeFormatter.ofPattern("HH:mm"))
        lastText = if (p == 0) {
            "Tudo feito hoje 🎉 · Nível ${st.level}"
        } else {
            "$p pendente(s) · Nível ${st.level} · próxima cobrança $hora"
        }
        getSystemService(NotificationManager::class.java).notify(ID_SERVICE, buildNotif(lastText))
    }

    /** Sem permissão de sobreposição: avisa por notificação. */
    private fun postFallback(t: Task) {
        val n = NotificationCompat.Builder(this, CH_REMIND)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(Msgs.ask(t))
            .setContentText("Libere \"Exibir sobre outros apps\" pra eu aparecer na tela.")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openAppIntent())
            .build()
        try {
            getSystemService(NotificationManager::class.java).notify(ID_REMIND, n)
        } catch (e: SecurityException) {
            Log.w("Rotina", "Sem permissão de notificação", e)
        }
    }
}
