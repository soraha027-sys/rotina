package com.rafael.rotina

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** Janela flutuante: balão com a tarefa + avatar. Some só ao tocar Feito/Versão mínima. */
class OverlayController(
    private val ctx: Context,
    private val onAnswer: (Task, Boolean) -> Unit,
) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val root = FrameLayout(ctx)
    private val column = LinearLayout(ctx)
    private val balloon = LinearLayout(ctx)
    private val msg = TextView(ctx)
    private val sub = TextView(ctx)
    private val hint = TextView(ctx)
    private val buttons = LinearLayout(ctx)
    private val btnDone = TextView(ctx)
    private val btnMin = TextView(ctx)
    private val avatar = AvatarView(ctx)
    private val confetti = ConfettiView(ctx)

    private var attached = false
    private var busy = false
    private var task: Task? = null

    var currentTaskId: Long = -1L
        private set

    val isShowing: Boolean get() = attached

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT,
    ).apply {
        gravity = Gravity.BOTTOM or Gravity.END
        x = dp(12)
        y = dp(140)
    }

    private fun dp(v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, radius: Int, stroke: Int, strokeW: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius.toFloat()
        setStroke(strokeW, stroke)
    }

    init {
        val ink = Color.parseColor("#1B1B2F")

        column.orientation = LinearLayout.VERTICAL
        column.gravity = Gravity.END

        balloon.orientation = LinearLayout.VERTICAL
        balloon.background = rounded(Color.WHITE, dp(18), ink, dp(3))
        balloon.setPadding(dp(14), dp(12), dp(14), dp(12))

        msg.setTextColor(ink)
        msg.textSize = 17f
        msg.typeface = Typeface.DEFAULT_BOLD

        sub.setTextColor(Color.parseColor("#555566"))
        sub.textSize = 13f

        hint.setTextColor(Color.parseColor("#888899"))
        hint.textSize = 11f
        hint.text = "Toque no bichinho pra minimizar · arraste pra mover"

        styleButton(btnDone, "✓ Feito", "#2EC4B6", ink)
        styleButton(btnMin, "½ Versão mínima", "#FFC857", ink)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.addView(btnDone, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(5) })
        buttons.addView(btnMin, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(5) })

        val full = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        balloon.addView(msg, LinearLayout.LayoutParams(full, wrap))
        balloon.addView(sub, LinearLayout.LayoutParams(full, wrap).apply { topMargin = dp(4) })
        balloon.addView(buttons, LinearLayout.LayoutParams(full, wrap).apply { topMargin = dp(10) })
        balloon.addView(hint, LinearLayout.LayoutParams(full, wrap).apply { topMargin = dp(8) })

        column.addView(balloon, LinearLayout.LayoutParams(dp(270), wrap))
        column.addView(avatar, LinearLayout.LayoutParams(dp(96), dp(112)).apply { topMargin = dp(2) })

        root.addView(column, FrameLayout.LayoutParams(wrap, wrap))
        root.addView(confetti, FrameLayout.LayoutParams(full, full))

        btnDone.setOnClickListener { answer(false) }
        btnMin.setOnClickListener { answer(true) }
        setupDrag()
    }

    private fun styleButton(b: TextView, text: String, color: String, ink: Int) {
        b.text = text
        b.gravity = Gravity.CENTER
        b.textSize = 15f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(ink)
        b.background = rounded(Color.parseColor(color), dp(14), ink, dp(2))
        b.isClickable = true
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupDrag() {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        avatar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = params.x
                    startY = params.y
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging && attached) {
                        params.x = (startX - dx).toInt()
                        params.y = (startY - dy).toInt()
                        try {
                            wm.updateViewLayout(root, params)
                        } catch (ex: Exception) {
                            Log.w("Rotina", "updateViewLayout", ex)
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) toggle()
                    true
                }
                else -> false
            }
        }
    }

    private fun toggle() {
        if (busy) return
        balloon.visibility = if (balloon.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun answer(minimal: Boolean) {
        if (busy) return
        val t = task ?: return
        busy = true
        onAnswer(t, minimal)
    }

    fun show(t: Task, text: String, mood: Mood) {
        task = t
        currentTaskId = t.id
        busy = false
        msg.text = text
        sub.text = "Versão mínima: ${t.minimal}"
        sub.visibility = View.VISIBLE
        buttons.visibility = View.VISIBLE
        hint.visibility = View.VISIBLE
        balloon.visibility = View.VISIBLE
        avatar.reload()
        avatar.mood = mood
        avatar.bounce()
        if (!attached) {
            try {
                wm.addView(root, params)
                attached = true
            } catch (e: Exception) {
                Log.e("Rotina", "Não consegui mostrar o avatar", e)
            }
        }
    }

    fun expandAndNudge(mood: Mood) {
        if (busy) return
        balloon.visibility = View.VISIBLE
        avatar.mood = mood
        avatar.bounce()
    }

    fun celebrate(text: String, onEnd: () -> Unit) {
        busy = true
        msg.text = text
        sub.visibility = View.GONE
        buttons.visibility = View.GONE
        hint.visibility = View.GONE
        balloon.visibility = View.VISIBLE
        avatar.mood = Mood.HAPPY
        confetti.post { confetti.burst() }
        root.postDelayed({ onEnd() }, 2600)
    }

    fun hide() {
        if (attached) {
            try {
                wm.removeView(root)
            } catch (e: Exception) {
                Log.w("Rotina", "removeView", e)
            }
            attached = false
        }
    }
}
